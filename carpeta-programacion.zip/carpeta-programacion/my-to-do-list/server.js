const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// Conexión a MongoDB
mongoose.connect('mongodb://127.0.0.1:27017/todo_db')
.then(() => console.log('✅ Conectado a MongoDB correctamente'))
.catch(err => console.error('❌ Error en MongoDB:', err));

// Esquema de Tareas
const TaskSchema = new mongoose.Schema({
  userId: String,
  whatsapp: String,
  text: String,
  description: String,
  category: String,
  dueDate: String,
  priority: String,
  completed: { type: Boolean, default: false }
});
const Task = mongoose.model('Task', TaskSchema);

// Esquema de Rachas
const StreakSchema = new mongoose.Schema({
  userId: String,
  appName: String,
  streakCount: { type: Number, default: 0 },
  lastPracticedDate: { type: String, default: '' }
});
const Streak = mongoose.model('Streak', StreakSchema);

// RUTAS TAREAS
app.get('/api/tasks', async (req, res) => {
  const userEmail = req.headers.authorization;
  if (!userEmail) return res.json([]);
  const tasks = await Task.find({ userId: userEmail });
  res.json(tasks);
});

app.post('/api/tasks', async (req, res) => {
  const userEmail = req.headers.authorization;
  const { text, description, category, dueDate, priority, whatsapp } = req.body;

  const newTask = new Task({
    userId: userEmail,
    whatsapp: whatsapp || '',
    text: text || 'Sin título',
    description: description || '',
    category: category || 'Escolar',
    dueDate: dueDate || '',
    priority: priority || 'normal',
    completed: false
  });
  await newTask.save();
  res.json(newTask);
});

// Ruta corregida para editar tareas con total seguridad
app.put('/api/tasks/:id', async (req, res) => {
  const { text, description, category, dueDate, priority } = req.body;
  const updatedTask = await Task.findByIdAndUpdate(
    req.params.id,
    { 
      text: text || 'Sin título', 
      description: description || '', 
      category: category || 'Escolar', 
      dueDate: dueDate || '', 
      priority: priority || 'normal' 
    },
    { new: true }
  );
  res.json(updatedTask);
});

app.patch('/api/tasks/:id', async (req, res) => {
  const task = await Task.findById(req.params.id);
  if (task) {
    task.completed = !task.completed;
    await task.save();
    res.json(task);
  } else {
    res.status(404).json({ error: 'No encontrada' });
  }
});

app.delete('/api/tasks/:id', async (req, res) => {
  await Task.findByIdAndDelete(req.params.id);
  res.json({ success: true });
});

// RUTAS RACHAS
const DEFAULT_APPS = ['Duolingo', 'Sounter', 'Cake', 'ABA English', 'Busuu', 'Babbel', 'Memrise', 'Drops'];

app.get('/api/streaks', async (req, res) => {
  const userEmail = req.headers.authorization;
  if (!userEmail) return res.json([]);

  let streaks = await Streak.find({ userId: userEmail });

  if (streaks.length < DEFAULT_APPS.length) {
    for (const appName of DEFAULT_APPS) {
      const exists = streaks.find(s => s.appName === appName);
      if (!exists) {
        const initialCount = appName === 'Duolingo' ? 209 : 0;
        await new Streak({ userId: userEmail, appName, streakCount: initialCount, lastPracticedDate: '' }).save();
      }
    }
    streaks = await Streak.find({ userId: userEmail });
  }
  res.json(streaks);
});

app.post('/api/streaks/practice', async (req, res) => {
  const userEmail = req.headers.authorization;
  const { appName } = req.body;
  const today = new Date().toISOString().split('T')[0];

  let streak = await Streak.findOne({ userId: userEmail, appName });
  if (streak) {
    if (streak.lastPracticedDate !== today) {
      streak.streakCount += 1;
      streak.lastPracticedDate = today;
      await streak.save();
    }
  }
  res.json(streak);
});

app.put('/api/streaks/set', async (req, res) => {
  const userEmail = req.headers.authorization;
  const { appName, newCount } = req.body;
  
  let streak = await Streak.findOne({ userId: userEmail, appName });
  if (streak) {
    streak.streakCount = parseInt(newCount) || 0;
    await streak.save();
  }
  res.json(streak);
});

const PORT = 3000;
app.listen(PORT, () => console.log(`🚀 Servidor listo en http://localhost:${PORT}`));