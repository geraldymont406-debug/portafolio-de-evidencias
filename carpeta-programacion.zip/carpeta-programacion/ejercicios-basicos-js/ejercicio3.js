// 3.Ingresar un número e indicar si es par o impar//

function ejecutarParImpar() {
    
    let numero = Number(prompt("Ingrese un número:"));
    if (numero % 2 === 0) {
        alert("El número ingresado " + numero + " es PAR.");
    } else {
        alert("El número ingresado " + numero + " es IMPAR.");
    }
}