// 4. Ingresar un número entero y mostrar los números del 1 hasta ese dato //

function ejecutarSecuenciaNumeros ()  {

let dato = parseInt(prompt("Ingrese un número entero positivo:"));

for (let i = 1; i <= dato; i = i + 2) {  
  alert(i);
}

}
// en vez suma 2 en 2