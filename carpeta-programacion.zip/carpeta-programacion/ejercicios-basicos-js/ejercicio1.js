// 1. Ingresar tu nombre y mostrarlo en la consola //

function ejecutarSaludoConsola() {

let persona = prompt("Please enter your name", "Dayani");

alert("¡Hola, " + persona + " ¡Bienvenido/a!");

}