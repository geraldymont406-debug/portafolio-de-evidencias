// 5. Ingresar números hasta que se ingrese un 0 y mostrar la suma de los positivos y la suma de los negativos//

function ejecutarSumaPositivosNegativos() {

let numero;
let positivos = 0;
let negativos = 0;

do {
    numero = Number(prompt("Ingresa un número. Escribe 0 para terminar:"));

    if (numero > 0) {
        positivos = positivos + numero;
    } 
    else if (numero < 0) {
        negativos = negativos + numero;
    }

} while (numero != 0);

alert("Suma de positivos: " + positivos);
alert("Suma de negativos: " + negativos);

}