// 2. Aceptar una lista de máximo 5 frutas y mostrarla en un arreglo//

function ejecutarListaFrutas() {
    const frutas = [];
    for (let i = 0; i < 5; i++) {
      let fruta = prompt("Ingresa el nombre de la fruta:");
      frutas[i] = fruta;
    }

    // Usamos JSON.stringify con formato para que mantenga los saltos y espacios iguales a la consola
    alert("Las frutas son:\n" + JSON.stringify(frutas, null, 2));
    alert("Frutas ordenadas:\n" + JSON.stringify(frutas.sort(), null, 2));
    alert("Eliminar la última fruta: " + frutas.pop());
}